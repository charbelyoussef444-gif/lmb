import uuid
from fastapi import APIRouter, Depends, HTTPException
from app.deps.auth import get_current_user_id
from app.services.supabase import sb  # must be service-role client for admin ops

router = APIRouter(prefix="/admin/users", tags=["admin-users"])

def require_admin(user_id: uuid.UUID = Depends(get_current_user_id)):
    db = sb.postgrest
    user = (
        db.from_("users")
        .select("admin")
        .eq("id", str(user_id))
        .single()
        .execute()
        .data
    )
    if not user or not user.get("admin"):
        raise HTTPException(403, "Admins only")
    return user_id

@router.get("")
async def list_users(
    _: uuid.UUID = Depends(require_admin),
    q: str | None = None,
    limit: int = 50,
    offset: int = 0,
):
    db = sb.postgrest
    req = (
        db.from_("users")
        .select("id,full_name,verified,banned,admin,created_at")
        .order("created_at", desc=True)
        .range(offset, offset + limit - 1)
    )
    if q:
        req = req.ilike("full_name", f"%{q}%")
    return req.execute().data

@router.post("/{target_user_id}/ban")
async def ban_user(target_user_id: uuid.UUID, _: uuid.UUID = Depends(require_admin)):
    sb.postgrest.from_("users").update({"banned": True}).eq("id", str(target_user_id)).execute()
    return {"ok": True}

@router.post("/{target_user_id}/unban")
async def unban_user(target_user_id: uuid.UUID, _: uuid.UUID = Depends(require_admin)):
    sb.postgrest.from_("users").update({"banned": False}).eq("id", str(target_user_id)).execute()
    return {"ok": True}

@router.post("/{target_user_id}/promote")
async def make_admin(target_user_id: uuid.UUID, _: uuid.UUID = Depends(require_admin)):
    sb.postgrest.from_("users").update({"admin": True}).eq("id", str(target_user_id)).execute()
    return {"ok": True}

@router.post("/{target_user_id}/demote")
async def revoke_admin(target_user_id: uuid.UUID, _: uuid.UUID = Depends(require_admin)):
    sb.postgrest.from_("users").update({"admin": False}).eq("id", str(target_user_id)).execute()
    return {"ok": True}
