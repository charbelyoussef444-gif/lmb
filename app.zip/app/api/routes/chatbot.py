import uuid
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text

from app.db.engine import engine
from app.deps.auth import get_current_user_id
from app.api.routes import chatbot_phase1, chatbot_phase2

router = APIRouter(prefix="/chatbot", tags=["chatbot"])

logger = logging.getLogger(__name__)

HISTORY_LIMIT = 8  # only for context if you want it later

# IMPORTANT: keep this in sync with CONFIDENCE_THRESHOLD in phase1/phase2
CONFIDENCE_THRESHOLD = 0.7


# ---------- DB helpers ----------


async def get_or_create_chatbot_conversation(conn, user_id: uuid.UUID) -> uuid.UUID:
    """
    Reuse / create a single 'onboarding_bot' conversation per user.
    """
    res = await conn.execute(
        text(
            """
            SELECT id
            FROM conversations
            WHERE user_a_id = :uid
              AND user_b_id IS NULL
              AND type = 'onboarding_bot'
            ORDER BY created_at ASC
            LIMIT 1
            """
        ),
        {"uid": str(user_id)},
    )
    row = res.mappings().first()
    if row:
        conv_id = uuid.UUID(str(row["id"]))
        logger.debug(
            "Reusing existing onboarding_bot conversation %s for user %s",
            conv_id,
            user_id,
        )
        return conv_id

    conv_id = uuid.uuid4()
    await conn.execute(
        text(
            """
            INSERT INTO conversations (
                id,
                type,
                user_a_id,
                user_b_id,
                active
            )
            VALUES (:cid, 'onboarding_bot', :uid, NULL, TRUE)
            """
        ),
        {"cid": str(conv_id), "uid": str(user_id)},
    )
    logger.debug(
        "Created new onboarding_bot conversation %s for user %s", conv_id, user_id
    )
    return conv_id


async def log_user_message(
    conn,
    conversation_id: uuid.UUID,
    user_id: uuid.UUID,
    content: str,
):
    await conn.execute(
        text(
            """
            INSERT INTO messages (
                conversation_id,
                sender_user_id,
                receiver_bot_id,
                message_type,
                content_text
            )
            VALUES (:cid, :uid, gen_random_uuid(), 'text', :content)
            """
        ),
        {"cid": str(conversation_id), "uid": str(user_id), "content": content},
    )
    logger.debug(
        "Logged USER message conv=%s user=%s: %.100r",
        conversation_id,
        user_id,
        content,
    )


async def log_bot_message(
    conn,
    conversation_id: uuid.UUID,
    user_id: uuid.UUID,
    content: str,
):
    """
    Single place where bot replies are written.
    Phase 1 & 2 return reply text; router logs here.
    """
    await conn.execute(
        text(
            """
            INSERT INTO messages (
                conversation_id,
                sender_bot_id,
                receiver_user_id,
                message_type,
                content_text
            )
            VALUES (:cid, gen_random_uuid(), :uid, 'text', :content)
            """
        ),
        {"cid": str(conversation_id), "uid": str(user_id), "content": content},
    )
    logger.debug(
        "Logged BOT message conv=%s user=%s: %.100r",
        conversation_id,
        user_id,
        content,
    )


async def fetch_all_traits(conn) -> list[dict]:
    res = await conn.execute(
        text(
            """
            SELECT id, name, description
            FROM personality_traits
            ORDER BY id ASC
            """
        )
    )
    rows = res.mappings().all()
    traits = [
        {
            "id": r["id"],
            "name": r["name"],
            "description": r["description"],
        }
        for r in rows
    ]
    logger.debug("Fetched %d traits", len(traits))
    return traits


async def fetch_user_personality_ids(
    conn,
    user_id: uuid.UUID,
    confidence_threshold: float,
) -> set[int]:
    """
    Phase 1 "done" traits = rows in user_personality where confidence >= threshold.
    """
    res = await conn.execute(
        text(
            """
            SELECT trait_id
            FROM user_personality
            WHERE user_id = :uid
              AND confidence IS NOT NULL
              AND confidence >= :thr
            """
        ),
        {"uid": str(user_id), "thr": confidence_threshold},
    )
    rows = res.mappings().all()
    ids = {r["trait_id"] for r in rows}
    logger.debug(
        "User %s SELF done traits (conf >= %.2f): %s",
        user_id,
        confidence_threshold,
        sorted(ids),
    )
    return ids


async def fetch_user_personality_pref_ids(
    conn,
    user_id: uuid.UUID,
    confidence_threshold: float,
) -> set[int]:
    """
    Phase 2 "done" traits = rows in user_personality_pref where confidence >= threshold.
    """
    res = await conn.execute(
        text(
            """
            SELECT trait_id
            FROM user_personality_pref
            WHERE user_id = :uid
              AND confidence IS NOT NULL
              AND confidence >= :thr
            """
        ),
        {"uid": str(user_id), "thr": confidence_threshold},
    )
    rows = res.mappings().all()
    ids = {r["trait_id"] for r in rows}
    logger.debug(
        "User %s PREF done traits (conf >= %.2f): %s",
        user_id,
        confidence_threshold,
        sorted(ids),
    )
    return ids


async def fetch_recent_convo_text(
    conn,
    conversation_id: uuid.UUID,
    limit: int = HISTORY_LIMIT,
) -> list[str]:
    res = await conn.execute(
        text(
            """
            SELECT content_text
            FROM messages
            WHERE conversation_id = :cid
              AND content_text IS NOT NULL
            ORDER BY created_at DESC
            LIMIT :lim
            """
        ),
        {"cid": str(conversation_id), "lim": limit},
    )
    rows = res.mappings().all()
    texts = [r["content_text"] for r in reversed(rows)]
    logger.debug(
        "Fetched %d recent convo messages for conv=%s", len(texts), conversation_id
    )
    return texts


async def fetch_conversation_messages(
    conn,
    conversation_id: uuid.UUID,
    limit: int = 200,
) -> list[dict]:
    """
    Full conversation history mapped to user/assistant roles.
    """
    res = await conn.execute(
        text(
            """
            SELECT
                sender_user_id,
                sender_bot_id,
                content_text,
                created_at
            FROM messages
            WHERE conversation_id = :cid
              AND content_text IS NOT NULL
            ORDER BY created_at ASC
            LIMIT :lim
            """
        ),
        {"cid": str(conversation_id), "lim": limit},
    )

    rows = res.mappings().all()
    messages: list[dict] = []
    for r in rows:
        role = "assistant" if r["sender_bot_id"] is not None else "user"
        messages.append(
            {
                "role": role,
                "content": r["content_text"],
                "ts": r["created_at"].isoformat(),
            }
        )
    logger.debug(
        "Fetched %d messages for history conv=%s", len(messages), conversation_id
    )
    return messages


# ---------------------------- ROUTES ----------------------------


@router.post("/message")
async def chatbot_message(
    payload: dict,
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    user_text = (payload.get("message") or "").strip()
    if not user_text:
        raise HTTPException(status_code=400, detail="message is required")

    logger.info("chatbot_message start user=%s text=%.120r", user_id, user_text)

    # 1) load shared state and log the user's message
    async with engine.begin() as conn:
        convo_id = await get_or_create_chatbot_conversation(conn, user_id)
        await log_user_message(conn, convo_id, user_id, user_text)

        all_traits = await fetch_all_traits(conn)
        total_traits = len(all_traits)

        # Phase 1 done = high-confidence self scores
        user_self_done = await fetch_user_personality_ids(
            conn, user_id, CONFIDENCE_THRESHOLD
        )
        # Phase 2 done = high-confidence preferences in user_personality_pref
        user_pref_done = await fetch_user_personality_pref_ids(
            conn, user_id, CONFIDENCE_THRESHOLD
        )

        history = await fetch_recent_convo_text(conn, convo_id, HISTORY_LIMIT)

    logger.info(
        "Phase routing for user=%s conv=%s | self_done=%d/%d, pref_done=%d/%d",
        user_id,
        convo_id,
        len(user_self_done),
        total_traits,
        len(user_pref_done),
        total_traits,
    )

    # 2) Phase 1: self-ratings (sequential, one trait hammered at a time)
    if len(user_self_done) < total_traits:
        logger.info("Routing to PHASE 1 (self)")
        result = await chatbot_phase1.handle_self_phase(
            user_id=user_id,
            conversation_id=convo_id,
            all_traits=all_traits,
            total_traits=total_traits,
            user_self_done=user_self_done,
            user_text=user_text,
            history=history,
        )
        reply = result.get("reply", "")
        if reply:
            async with engine.begin() as conn:
                await log_bot_message(conn, convo_id, user_id, reply)
        return result

    # 3) Phase 2: partner preferences / importance
    if len(user_pref_done) < total_traits:
        logger.info("Routing to PHASE 2 (preferences)")
        result = await chatbot_phase2.handle_importance_phase(
            user_id=user_id,
            conversation_id=convo_id,
            all_traits=all_traits,
            total_traits=total_traits,
            user_importance_done=user_pref_done,
            user_text=user_text,
            history=history,
        )
        reply = result.get("reply", "")
        if reply:
            async with engine.begin() as conn:
                await log_bot_message(conn, convo_id, user_id, reply)
        return result

    # 4) Done – both phases complete
    logger.info("Routing to PHASE DONE for user=%s conv=%s", user_id, convo_id)
    final_msg = (
        "You're fully profiled ✅ If anything changes, just tell me and I'll update."
    )
    async with engine.begin() as conn:
        await log_bot_message(conn, convo_id, user_id, final_msg)

    return {
        "reply": final_msg,
        "phase": "done",
    }


@router.get("/history")
async def chatbot_history(
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    async with engine.begin() as conn:
        convo_id = await get_or_create_chatbot_conversation(conn, user_id)
        messages = await fetch_conversation_messages(conn, convo_id, limit=200)

        all_traits = await fetch_all_traits(conn)
        total_traits = len(all_traits)
        user_self_done = await fetch_user_personality_ids(
            conn, user_id, CONFIDENCE_THRESHOLD
        )
        user_pref_done = await fetch_user_personality_pref_ids(
            conn, user_id, CONFIDENCE_THRESHOLD
        )

    if len(user_self_done) < total_traits:
        phase = "self"
    elif len(user_pref_done) < total_traits:
        phase = "pref"
    else:
        phase = "done"

    logger.info(
        "chatbot_history user=%s conv=%s -> phase=%s | self_done=%d/%d pref_done=%d/%d",
        user_id,
        convo_id,
        phase,
        len(user_self_done),
        total_traits,
        len(user_pref_done),
        total_traits,
    )

    return {
        "messages": messages,
        "phase": phase,
        "progress": {
            "self_filled": len(user_self_done),
            "self_total": total_traits,
            "pref_filled": len(user_pref_done),
            "pref_total": total_traits,
        },
    }
