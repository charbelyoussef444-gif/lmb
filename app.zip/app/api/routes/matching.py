import uuid
import math
from datetime import datetime, timedelta, date, timezone
from typing import Optional, Literal, Union, List, Dict, Set, Tuple
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from app.db.engine import engine
from app.deps.auth import get_current_user_id
from pydantic import BaseModel, Field

router = APIRouter(prefix="/matching", tags=["matching"])

# ---------------------------
# constants / tuning
# ---------------------------
TRAIT_COUNT_EXPECTED = 10
MIN_PREF_COVERAGE = 0.7            # 70% of prefs must be filled
COOLDOWN_HOURS = 24
MAX_ACTIVE_CHATS = 3
MIN_AGE = 18


# ---------------------------
# Response schemas
# ---------------------------
class MatchResultIneligible(BaseModel):
    status: Literal["ineligible"]
    user_id: str
    reason: str


class MatchResultNoMatch(BaseModel):
    status: Literal["no_match"]
    user_id: str


class MatchResultSuccess(BaseModel):
    status: Literal["matched"]
    user_a_id: str
    user_b_id: str
    score: float = Field(..., description="final match score 0..1-ish")
    conversation_id: str


MatchResult = Union[MatchResultIneligible, MatchResultNoMatch, MatchResultSuccess]


# ---------------------------
# helpers to talk to DB
# ---------------------------

async def _fetch_user(conn, user_id: str):
    row = (await conn.execute(text("""
        select
            id::text              as id,
            full_name,
            gender,
            gender_pref,
            age,
            location,
            verified,
            active_chats,
            personality_weight,
            interests_weight,
            last_match_date,
            last_active,
            created_at,
            updated_at
        from users
        where id = :uid
    """), {"uid": user_id})).mappings().first()
    return row


async def _personality_map(conn, user_id: str) -> Dict[int, float]:
    rows = (await conn.execute(text("""
        select trait_id, score
        from user_personality
        where user_id = :uid
    """), {"uid": user_id})).mappings().all()
    return {r["trait_id"]: float(r["score"]) for r in rows}


async def _pref_map(conn, user_id: str) -> Dict[int, float]:
    rows = (await conn.execute(text("""
        select trait_id, score
        from user_personality_pref
        where user_id = :uid
    """), {"uid": user_id})).mappings().all()
    return {r["trait_id"]: float(r["score"]) for r in rows}


async def _interests_set(conn, user_id: str) -> Set[str]:
    rows = (await conn.execute(text("""
        select i.name
        from user_interests ui
        join interests i on i.id = ui.interest_id
        where ui.user_id = :uid
    """), {"uid": user_id})).mappings().all()
    return {r["name"] for r in rows}


async def _count_personality_rows(conn, user_id: str) -> int:
    r = (await conn.execute(text("""
        select count(*) as c
        from user_personality
        where user_id = :uid
    """), {"uid": user_id})).first()
    return int(r[0])


async def _count_pref_rows(conn, user_id: str) -> int:
    r = (await conn.execute(text("""
        select count(*) as c
        from user_personality_pref
        where user_id = :uid
    """), {"uid": user_id})).first()
    return int(r[0])


async def _already_matched(conn, a_id: str, b_id: str) -> bool:
    row = (await conn.execute(text("""
        select id
        from conversations
        where type = 'match'
          and (
                (user_a_id = :a and user_b_id = :b)
             or (user_a_id = :b and user_b_id = :a)
          )
        limit 1
    """), {"a": a_id, "b": b_id})).first()
    return row is not None


# ---------------------------
# scoring helpers (pure python)
# ---------------------------

def _directional_personality_score(
    prefs_from_A: Dict[int, float],
    traits_of_B: Dict[int, float],
) -> Optional[float]:
    sims: List[float] = []
    for tid, score_val in prefs_from_A.items():
        if tid not in traits_of_B:
            continue
        b_val = traits_of_B[tid]
        diff = abs(score_val - b_val)
        sim = 1.0 - diff
        if sim < 0:
            sim = 0.0
        sims.append(sim)
    if not sims:
        return None
    return sum(sims) / len(sims)


def _personality_match_score(
    a_traits: Dict[int, float],
    b_traits: Dict[int, float],
    a_prefs: Dict[int, float],
    b_prefs: Dict[int, float],
) -> Optional[float]:
    pa = _directional_personality_score(a_prefs, b_traits)
    pb = _directional_personality_score(b_prefs, a_traits)
    if pa is None or pb is None:
        return None
    if pa <= 0 or pb <= 0:
        return 0.0
    return math.sqrt(pa * pb)


def _interest_score(a_set: Set[str], b_set: Set[str]) -> Optional[float]:
    if not a_set and not b_set:
        return None
    shared = a_set.intersection(b_set)

    def safe_div(n: int, d: int) -> float:
        return (n / d) if d > 0 else 0.0

    a_ratio = safe_div(len(shared), len(a_set))
    b_ratio = safe_div(len(shared), len(b_set))
    return (a_ratio + b_ratio) / 2.0


def _final_score(
    a_user_row,
    b_user_row,
    personality_score: Optional[float],
    interest_score: Optional[float],
) -> float:
    # personality weight averaging
    pw_a = float(a_user_row["personality_weight"])
    pw_b = float(b_user_row["personality_weight"])
    pw = (pw_a + pw_b) / 2.0
    if pw < 0:
        pw = 0.0
    if pw > 1:
        pw = 1.0
    iw = 1.0 - pw

    p = personality_score if personality_score is not None else 0.0
    i = interest_score if interest_score is not None else 0.0
    return pw * p + iw * i


# ---------------------------
# gender / gender_pref logic
# ---------------------------

def _pref_allows_gender(pref: str, other_gender: str) -> bool:
    """
    DB values:
      gender:      'man' | 'woman' | 'nonbinary'
      gender_pref: 'men' | 'women' | 'everyone'

    Rules:
      - NULL / '' / 'everyone'  => no restriction
      - 'men'   => only matches partners with gender 'man'
      - 'women' => only matches partners with gender 'woman'
    """
    pref = (pref or "").strip().lower()
    other_gender = (other_gender or "").strip().lower()

    if not pref or pref == "everyone":
        return True

    if pref == "men":
        return other_gender == "man"

    if pref == "women":
        return other_gender == "woman"

    # If something unexpected is stored, don't hard-block everything.
    return True


def _gender_match_ok(a_row, b_row) -> bool:
    """
    Enforce gender preference using DB conventions:
      gender:      'man' | 'woman' | 'nonbinary'
      gender_pref: 'men' | 'women' | 'everyone'
    """
    a_pref = (a_row.get("gender_pref") or "").strip().lower()
    b_pref = (b_row.get("gender_pref") or "").strip().lower()
    a_gender = (a_row.get("gender") or "").strip().lower()
    b_gender = (b_row.get("gender") or "").strip().lower()

    # A's requirement on B
    if not _pref_allows_gender(a_pref, b_gender):
        return False

    # B's requirement on A
    if not _pref_allows_gender(b_pref, a_gender):
        return False

    return True


# ---------------------------
# eligibility checks
# ---------------------------

async def _is_user_eligible(conn, user_row) -> Tuple[bool, Optional[str]]:
    if not user_row:
        return False, "User not found"

    # age
    if user_row["age"] is None or user_row["age"] < MIN_AGE:
        return False, "Age restriction"

    # verified
    if not user_row["verified"]:
        return False, "User not verified"

    # active chats
    active_chats = user_row["active_chats"] or 0
    if active_chats >= MAX_ACTIVE_CHATS:
        return False, "Active chats limit reached"

    # cooldown on last_match_date (now treated as timestamp)
    last_match_ts = user_row["last_match_date"]
    if last_match_ts:
        # normalize to naive UTC for comparison with datetime.utcnow()
        if getattr(last_match_ts, "tzinfo", None) is not None:
            lm_utc = last_match_ts.astimezone(timezone.utc).replace(tzinfo=None)
        else:
            lm_utc = last_match_ts

        cutoff_dt = datetime.utcnow() - timedelta(hours=COOLDOWN_HOURS)
        if lm_utc > cutoff_dt:
            return False, "Cooldown not finished"

    # personality coverage
    trait_count = await _count_personality_rows(conn, user_row["id"])
    if trait_count < TRAIT_COUNT_EXPECTED:
        return False, "Personality incomplete"

    # pref coverage
    pref_count = await _count_pref_rows(conn, user_row["id"])
    min_required = int(TRAIT_COUNT_EXPECTED * MIN_PREF_COVERAGE)
    if pref_count < min_required:
        return False, "Preferences incomplete"

    return True, None


async def _fetch_candidate_pool(conn, a_user_id: str):
    """
    All Bs that are:
    - not A
    - verified
    - active_chats < MAX_ACTIVE_CHATS
    - have full personality coverage
    - have enough prefs coverage
    We'll filter again with _is_user_eligible to be strict/symmetric.
    """

    min_required_prefs = int(TRAIT_COUNT_EXPECTED * MIN_PREF_COVERAGE)

    rows = (await conn.execute(text(f"""
        with trait_counts as (
            select user_id, count(*) as trait_count
            from user_personality
            group by user_id
        ),
        pref_counts as (
            select user_id, count(*) as pref_count
            from user_personality_pref
            group by user_id
        )
        select
            u.id::text              as id,
            u.full_name,
            u.gender,
            u.gender_pref,
            u.age,
            u.location,
            u.verified,
            u.active_chats,
            u.personality_weight,
            u.interests_weight,
            u.last_match_date,
            u.last_active,
            u.created_at,
            u.updated_at,
            tc.trait_count,
            pc.pref_count
        from users u
        join trait_counts tc on tc.user_id = u.id
        join pref_counts  pc on pc.user_id = u.id
        where u.id <> :me
          and u.verified = true
          and (u.active_chats < :max_chats)
          and tc.trait_count >= :trait_expected
          and pc.pref_count  >= :pref_required
    """), {
        "me": a_user_id,
        "max_chats": MAX_ACTIVE_CHATS,
        "trait_expected": TRAIT_COUNT_EXPECTED,
        "pref_required": min_required_prefs,
    })).mappings().all()

    return rows


async def _create_conversation_and_stamp(
    conn,
    a_id: str,
    b_id: str,
    match_score: float,
) -> str:
    new_cid = str(uuid.uuid4())

    # insert conversation WITH match_score
    await conn.execute(text("""
        insert into conversations(
            id,
            type,
            user_a_id,
            user_b_id,
            active,
            match_score,
            created_at,
            updated_at
        )
        values (:cid, 'match', :a, :b, true, :ms, now(), now())
    """), {
        "cid": new_cid,
        "a": a_id,
        "b": b_id,
        "ms": match_score,
    })

    # update both users' last_match_date with FULL TIMESTAMP (now)
    await conn.execute(text("""
        update users
        set last_match_date = now(),
            updated_at = now()
        where id in (:a, :b)
    """), {"a": a_id, "b": b_id})

    # increment active_chats for BOTH users
    await conn.execute(text("""
        update users
        set active_chats = active_chats + 1,
            updated_at = now()
        where id in (:a, :b)
    """), {"a": a_id, "b": b_id})

    return new_cid


# ---------------------------
# CORE ROUTES
# ---------------------------
@router.get("/status")
async def get_matching_status(
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    """
    Returns:
    {
      eligible: boolean,
      reason: string | null,
      next_eligible_ts_utc: string | null,   // ISO timestamp when they can next match
    }
    """
    async with engine.begin() as conn:
        user_row = await _fetch_user(conn, str(user_id))
        ok, reason = await _is_user_eligible(conn, user_row)

        next_eligible_ts_utc = None

        if not ok and user_row and user_row["last_match_date"]:
            last_match_ts = user_row["last_match_date"]

            if getattr(last_match_ts, "tzinfo", None) is not None:
                lm_utc = last_match_ts.astimezone(timezone.utc)
            else:
                lm_utc = last_match_ts.replace(tzinfo=timezone.utc)

            next_allowed_dt = lm_utc + timedelta(hours=COOLDOWN_HOURS)
            next_eligible_ts_utc = next_allowed_dt.isoformat().replace("+00:00", "Z")

        return {
            "eligible": bool(ok),
            "reason": reason,
            "next_eligible_ts_utc": next_eligible_ts_utc,
        }


@router.post("/generate", response_model=MatchResult)
async def generate_match(
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    """
    Generate (or attempt to generate) a match for the calling user.
    """

    async with engine.begin() as conn:
        # 1. Load A
        a_row = await _fetch_user(conn, str(user_id))

        # 2. Check eligibility for A
        ok, reason = await _is_user_eligible(conn, a_row)
        if not ok:
            return MatchResultIneligible(
                status="ineligible",
                user_id=str(user_id),
                reason=reason or "not_eligible",
            )

        # Preload A's maps/sets once
        a_traits = await _personality_map(conn, a_row["id"])
        a_prefs  = await _pref_map(conn, a_row["id"])
        a_interests = await _interests_set(conn, a_row["id"])

        # 3. Build candidate pool
        candidates = await _fetch_candidate_pool(conn, a_row["id"])

        best_candidate = None
        best_score_val: Optional[float] = None

        for b_row in candidates:
            # Enforce mutual gender preference rules
            if not _gender_match_ok(a_row, b_row):
                continue

            # strict symmetric eligibility: B must also be eligible
            b_ok, _ = await _is_user_eligible(conn, b_row)
            if not b_ok:
                continue

            # skip if already matched in conversations
            if await _already_matched(conn, a_row["id"], b_row["id"]):
                continue

            # load B details
            b_traits = await _personality_map(conn, b_row["id"])
            b_prefs  = await _pref_map(conn, b_row["id"])
            b_interests = await _interests_set(conn, b_row["id"])

            # personality
            p_score = _personality_match_score(
                a_traits=a_traits,
                b_traits=b_traits,
                a_prefs=a_prefs,
                b_prefs=b_prefs,
            )

            # interests
            i_score = _interest_score(a_interests, b_interests)

            # if literally NO signal at all, skip
            if p_score is None and i_score is None:
                continue

            # final score
            fs = _final_score(
                a_user_row=a_row,
                b_user_row=b_row,
                personality_score=p_score,
                interest_score=i_score,
            )

            if best_score_val is None or fs > best_score_val:
                best_score_val = fs
                best_candidate = b_row

        # 4. If nobody found
        if best_candidate is None:
            return MatchResultNoMatch(
                status="no_match",
                user_id=str(user_id),
            )

        # guard in case best_score_val somehow stayed None
        final_score_for_db = float(best_score_val or 0.0)

        # 5. Create conversation + stamp last_match_date for both
        convo_id = await _create_conversation_and_stamp(
            conn,
            a_row["id"],
            best_candidate["id"],
            final_score_for_db,
        )

        # 6. Return response
        return MatchResultSuccess(
            status="matched",
            user_a_id=a_row["id"],
            user_b_id=best_candidate["id"],
            score=round(final_score_for_db, 4),
            conversation_id=convo_id,
        )
