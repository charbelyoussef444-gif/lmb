import os
import random
import re
import uuid
import json
import asyncio
import logging
from typing import Dict, List, Optional, Set, Any

from sqlalchemy import text
from openai import OpenAI

from app.db.engine import engine

logger = logging.getLogger(__name__)

OPENAI_MODEL = "gpt-4o"

EMOJIS = ["🙂", "😊", "😄", "🌟", "💫", "💛", "💙", "🌈", "✨", "🧠"]

# Sequential: we effectively focus on ONE trait at a time now.
TRAITS_PER_BATCH = 1

# Confidence at which we treat a trait as "good enough" for routing
CONFIDENCE_THRESHOLD = 0.7

# Trait anchors reused for preferences.
TRAIT_DEFINITIONS: Dict[int, str] = {
    1: (
        "Warmth / Compassion: genuine concern for others’ well-being and a "
        "nurturing, caring style in close relationships."
    ),
    2: (
        "Honesty–Humility: inclination toward fairness, sincerity, and modesty "
        "rather than entitlement or exploitation."
    ),
    3: (
        "Attachment Anxiety: fear of rejection or abandonment and "
        "hypervigilance about a partner’s signals."
    ),
    4: (
        "Attachment Avoidance: discomfort with dependence or emotional "
        "intimacy and a strong preference for self-reliance."
    ),
    5: (
        "Openness — Aesthetic / Experiential: receptivity to sensory, artistic, "
        "and novel experiences."
    ),
    6: (
        "Repair Orientation: readiness to take ownership, apologize, and "
        "initiate repair after conflict."
    ),
    7: (
        "Autonomy / Boundary Respect: respect for a partner’s independence and "
        "avoidance of controlling behavior."
    ),
    8: (
        "Communication Clarity / Directness: ability to express needs, "
        "feelings, and boundaries openly and concretely."
    ),
    9: (
        "Reliability / Dependability in Dyad: consistency in keeping promises, "
        "showing up, and being someone a partner can count on."
    ),
    10: (
        "Exclusivity Preference: personal comfort and desire for strict "
        "monogamy versus openness to consensual non-monogamy or more flexible "
        "relationship structures."
    ),
}


def get_openai_client() -> OpenAI:
    return OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


# ---------- small helpers ----------


def _extract_number(user_text: str) -> Optional[float]:
    """
    Pull the first float-like number out of user_text.
    Kept for potential future use.
    """
    matches = re.findall(r"[-+]?\d*\.?\d+", user_text)
    if not matches:
        return None
    try:
        value = float(matches[0])
    except ValueError:
        return None

    if 0.0 <= value <= 1.0:
        return value
    if 1.0 < value <= 100.0:
        return value / 100.0
    return None


async def _upsert_user_personality_pref(
    conn,
    user_id: uuid.UUID,
    trait_id: int,
    score: float,
    confidence: float,
):
    """
    Upsert the user's partner-preference trait score + confidence.

    Table: user_personality_pref(user_id, trait_id, score, confidence).
    """
    await conn.execute(
        text(
            """
            INSERT INTO user_personality_pref (user_id, trait_id, score, confidence)
            VALUES (:uid, :tid, :score, :conf)
            ON CONFLICT (user_id, trait_id)
            DO UPDATE SET
                score = EXCLUDED.score,
                confidence = EXCLUDED.confidence
            """
        ),
        {
            "uid": str(user_id),
            "tid": trait_id,
            "score": score,
            "conf": confidence,
        },
    )
    logger.debug(
        "Upserted PREF score user=%s trait=%s score=%.4f confidence=%.4f",
        user_id,
        trait_id,
        score,
        confidence,
    )


def _add_random_emoji(text: str) -> str:
    t = text.rstrip()
    lower = t.lower()

    if any(k in lower for k in ["technical hiccup", "got a bit lost"]):
        return t

    if "OPTIONS:" in t:
        return t

    if random.random() < 0.6:
        emoji = random.choice(EMOJIS)
        return f"{t} {emoji}"
    return t


def _build_history_snippet(history: List[str], max_items: int = 6) -> str:
    if not history:
        return ""
    labeled: List[str] = []
    start = max(0, len(history) - max_items)
    for idx, h in enumerate(history[start:], start=start + 1):
        labeled.append(f"Turn {idx}: {h}")
    snippet = "\n\n".join(labeled)
    logger.debug("History snippet for PREF model:\n%s", snippet)
    return snippet


def _prepare_traits_for_prompt(
    traits: List[dict],
    existing_state: Optional[Dict[int, Dict[str, Optional[float]]]] = None,
) -> List[dict]:
    """
    Normalize traits into a compact JSON payload for the model.
    """
    prepared: List[dict] = []
    existing_state = existing_state or {}

    for t in traits:
        try:
            tid = int(t["id"])
        except (KeyError, TypeError, ValueError):
            continue

        name = t.get("name", f"Trait {tid}")
        description = TRAIT_DEFINITIONS.get(tid)
        if not description:
            description = (
                f"{name}: how this dimension shows up in the kind of partner "
                "and relationship they are drawn to or reject."
            )

        trait_payload: Dict[str, Any] = {
            "id": tid,
            "name": name,
            "description": description,
        }

        state = existing_state.get(tid)
        if state is not None:
            if state.get("score") is not None:
                trait_payload["current_value"] = float(state["score"])
            if state.get("confidence") is not None:
                trait_payload["current_confidence"] = float(state["confidence"])

        prepared.append(trait_payload)

    logger.debug("Prepared PREF traits for model: %s", prepared)
    return prepared


# ---------- OpenAI call: PHASE 2 (preferences) ----------


async def _call_openai_for_importance_analysis(
    traits: List[dict],
    history: List[str],
    user_text: str,
    existing_state: Optional[Dict[int, Dict[str, Optional[float]]]] = None,
) -> Dict:
    """
    Phase 2:
      - Infer 0–1 partner-preference trait scores + confidence for the ACTIVE trait.
      - Psychologically: CONTRAST / BEHAVIOR / FORCED CHOICE.
    """
    client = get_openai_client()

    prepared_traits = _prepare_traits_for_prompt(traits, existing_state=existing_state)

    payload = {
        "traits": prepared_traits,
        "recent_history": _build_history_snippet(history),
        "latest_user_message": user_text,
    }

    logger.debug(
        "Calling OpenAI PREF-phase with payload: %s",
        json.dumps(payload, ensure_ascii=False),
    )

    system_prompt = """
You are a sharp, slightly provocative relationship-matching profiler for a dating app.

OVERALL GOAL
- Phase 1 already mapped who they are.
- Your job now is to map what *actually matters* in a match for them:
  1) What they reject / will never date.
  2) What they keep falling for or getting bored by.
  3) Which tradeoffs they pick when they can’t have everything.

You infer quantitative trait scores (0–1) for the partner-preference traits you are given,
but you never show numbers to the user.
You talk in normal language about patterns, types of people, situations, and feelings.

RELATIONSHIP STATUS / FRAMING
- Never assume they currently have a partner.
- Use flexible framing:
  - “if/when you’re seeing someone…”
  - “in close relationships (friends, family, or when you’re with a partner)…”
- Avoid wording that assumes a current partner.

PHASE LOGIC (CONTRAST → BEHAVIOR → FORCED CHOICE)

1) CONTRAST — break polite answers with dealbreakers
   Goal: get their hard no’s and instant turn-offs.

   When:
   - Little or no info yet on this trait.
   - No clear turn-offs in the history.

   How:
   - Ask about experiences or patterns, NOT assuming they’ve happened:
     - “Think about a time—or imagine a situation if it hasn’t really happened—where you realised ‘never again’ with someone. What was going on?”
     - “What kind of behaviour would instantly kill attraction for you, even if the person looked great on paper?”
     - “When you picture your ‘absolutely not’ type for this, what do they do or how do they treat people?”
   - Do NOT force them to name a specific person. Situations and imagined scenarios are fine.

2) BEHAVIOR — ignore opinions, read their history
   Goal: see what they actually move toward or away from.

   When:
   - You already have some red flags or boundaries for this trait.
   - They’ve started talking about past relationships, crushes, or near-misses.

   How:
   - Focus on experiences, feelings, and patterns:
     - “Think about a time you felt really drawn in—or imagine the kind of situation that would do it. What about their behaviour or vibe pulls you in?”
     - “Remember (or picture) a situation where you realised you were bored romantically. What was happening?”
     - “Was there a time, or an imagined scenario, where you’d keep chasing someone even if things felt a bit off? What’s attractive about that?”
   - It’s okay if they answer with a story or a hypothetical; either is useful.

3) FORCED CHOICE — expose priorities with tradeoffs
   Goal: rank what matters by forcing them to lean one way.

   When:
   - You have plenty of qualitative data.
   - You need a clearer hierarchy for this trait.

   How:
   - Use clean either–or questions, framed as “which matters more *for you*”:
     - “If you had to choose: emotionally deep or naturally fun?”
     - “Safer and loyal or more exciting and unpredictable?”
     - “Strong communicator or intense chemistry?”
     - “Ambitious or emotionally available?”
     - “Calm and stable or passionate and volatile?”
   - If they try to pick both, nudge:
     - “When you think about real or imagined situations, which side feels more important to you?”

QUESTION STYLE (IMPORTANT)
- Never ask generic “What do you look for in a partner?”.
- You MUST NOT assume that a specific event actually happened.
  - Always give them an explicit out:
    - “If nothing specific comes to mind, describe the kind of situation or feeling that fits.”
    - “This can be something that really happened or something you can clearly imagine.”
- You may mention “someone”, but you must NOT require that they recall a concrete person.
- One focused open question per turn. No multiple-choice menus.

NUMERIC SCALE
- 0.0 = they barely care about this dimension / it’s not important.
- 0.5 = mixed / context-dependent.
- 1.0 = very important / strong preference or boundary.

CONFIDENCE
- ~0.3: weak hunch.
- ~0.5: moderate.
- ~0.7+: strong; only change if user clearly contradicts it.

STYLE / UX
- Tone: direct, playful, a bit incisive, but never cruel.
- Reply length: max ~2–3 short sentences OR ~60 words.
- You never mention scores or “traits” explicitly to the user.
- End with exactly one short question (unless wrapping the trait).

OUTPUT FORMAT (STRICT)
Respond as a single valid JSON object, with no extra text, no markdown:

{
  "reply": "<what you say to the user in natural language>",
  "inferred": [
    {
      "trait_id": <int from the 'traits' payload>,
      "trait_name": "<string>",
      "value": <float between 0 and 1>,
      "confidence": <float between 0 and 1>,
      "explanation": "<short, plain-language reason tied to their boundaries, stories, or forced choices>"
    },
    ...
  ]
}
"""
    try:
        loop = asyncio.get_event_loop()
        completion = await loop.run_in_executor(
            None,
            lambda: client.chat.completions.create(
                model=OPENAI_MODEL,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": json.dumps(payload),
                    },
                ],
                temperature=0.3,
            ),
        )
    except Exception as e:
        logger.exception("OpenAI API call failed in PREF phase: %s", e)
        return {
            "reply": (
                "I'm having a small technical hiccup. "
                "Tell me a bit more about the kind of situations or behaviours you’d never want to deal with again."
            ),
            "inferred": [],
        }

    raw = (completion.choices[0].message.content or "").strip()
    logger.debug("PREF raw OpenAI response: %s", raw)

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        logger.warning("JSON decode error in PREF phase: %s | raw=%r", e, raw)
        return {
            "reply": (
                "I got a bit lost in that last part. "
                "Tell me again about a situation—real or imagined—that would completely kill your attraction and why."
            ),
            "inferred": [],
        }

    if not isinstance(data, dict):
        logger.warning("PREF response was not a dict, got: %r", type(data))
        data = {}

    if "reply" not in data or not isinstance(data["reply"], str):
        data["reply"] = (
            "Got it. Tell me a bit more about the kinds of situations where you realise someone is or isn’t for you."
        )

    if "inferred" not in data or not isinstance(data["inferred"], list):
        data["inferred"] = []

    logger.debug("Parsed PREF data: %s", data)
    return data


# ---------- main Phase 2 handler ----------


async def handle_importance_phase(
    user_id: uuid.UUID,
    conversation_id: uuid.UUID,
    all_traits: List[dict],
    total_traits: int,
    user_importance_done: Set[int],
    user_text: str,
    history: List[str],
) -> Dict:
    """
    Phase 2: partner preferences in user_personality_pref, strictly sequential.

    - Only move to the next trait when the current trait's confidence
      reaches CONFIDENCE_THRESHOLD (>= 0.7).
    - Exactly one active trait is being pushed at a time.
    """
    request_id = uuid.uuid4()
    logger.info(
        "[PREF] start request_id=%s user=%s conv=%s text=%r",
        request_id,
        user_id,
        conversation_id,
        user_text,
    )

    # Fetch existing preference state (score + confidence)
    async with engine.begin() as conn:
        result = await conn.execute(
            text(
                """
                SELECT trait_id, score, confidence
                FROM user_personality_pref
                WHERE user_id = :uid
                """
            ),
            {"uid": str(user_id)},
        )
        rows = result.fetchall()

    existing_state: Dict[int, Dict[str, Optional[float]]] = {}
    for row in rows:
        m = row._mapping
        try:
            tid = int(m["trait_id"])
        except (KeyError, TypeError, ValueError):
            continue
        existing_state[tid] = {
            "score": m.get("score"),
            "confidence": m.get("confidence"),
        }

    logger.debug("[PREF %s] existing_state=%s", request_id, existing_state)

    # Traits that are not yet "done" according to router (confidence >= threshold)
    new_importance_done: Set[int] = set(user_importance_done)

    remaining_traits = [t for t in all_traits if int(t["id"]) not in new_importance_done]
    logger.debug(
        "[PREF %s] remaining_traits_ids=%s",
        request_id,
        [t["id"] for t in remaining_traits],
    )

    if not remaining_traits:
        msg = (
            "I’ve already got a clear map of what matters most to you in a match. "
            "From here, it’s all about using it intelligently."
        )
        msg = _add_random_emoji(msg)
        logger.info("[PREF %s] all traits done, replying with summary", request_id)
        return {
            "reply": msg,
            "phase": "importance",
            "progress": {
                "importance_filled": len(new_importance_done),
                "importance_total": total_traits,
            },
            "importance_done": sorted(new_importance_done),
        }

    # STRICTLY SEQUENTIAL:
    # Always focus on the first trait that is not yet done.
    active_trait = remaining_traits[0]
    active_traits = [active_trait]
    active_ids = {int(active_trait["id"])}
    logger.debug("[PREF %s] active_traits_ids=%s", request_id, sorted(active_ids))

    # Build prior state for that active trait only
    active_existing_state: Dict[int, Dict[str, Optional[float]]] = {
        tid: existing_state.get(tid, {"score": None, "confidence": None})
        for tid in active_ids
    }

    analysis = await _call_openai_for_importance_analysis(
        traits=active_traits,
        history=history,
        user_text=user_text,
        existing_state=active_existing_state,
    )

    reply_text = (analysis.get("reply") or "").strip()
    if not reply_text:
        reply_text = (
            "Got it. Tell me a bit more about the kinds of situations where you notice someone feels right or wrong for you."
        )

    inferred = analysis.get("inferred") or []
    logger.debug("[PREF %s] inferred=%s", request_id, inferred)

    updated: Dict[str, float] = {}
    updated_debug: Dict[str, Dict[str, Optional[float]]] = {}

    async with engine.begin() as conn:
        # Store ALL inferences that pass sanity checks.
        for item in inferred:
            try:
                trait_id = int(item.get("trait_id"))
                value = float(item.get("value"))
                confidence = float(item.get("confidence", 0.0))
            except (TypeError, ValueError):
                logger.warning("[PREF %s] Invalid inferred item: %r", request_id, item)
                continue

            if trait_id not in active_ids:
                logger.debug(
                    "[PREF %s] skipping inferred trait_id=%s not in active_ids=%s",
                    request_id,
                    trait_id,
                    active_ids,
                )
                continue

            # Clamp to [0, 1]
            value = max(0.0, min(1.0, value))
            confidence = max(0.0, min(1.0, confidence))

            # Enforce monotonic confidence: never let it go down
            prev_state = existing_state.get(trait_id, {})
            prev_conf_raw = prev_state.get("confidence")
            try:
                prev_conf = float(prev_conf_raw) if prev_conf_raw is not None else None
            except (TypeError, ValueError):
                prev_conf = None

            if prev_conf is not None and prev_conf > confidence:
                logger.debug(
                    "[PREF %s] keeping higher previous confidence for trait=%s: prev=%.4f new=%.4f",
                    request_id,
                    trait_id,
                    prev_conf,
                    confidence,
                )
                confidence = prev_conf

            await _upsert_user_personality_pref(conn, user_id, trait_id, value, confidence)
            updated[str(trait_id)] = value

            existing_state[trait_id] = {"score": value, "confidence": confidence}
            updated_debug[str(trait_id)] = {
                "score": value,
                "confidence": confidence,
            }

            # Mark done locally if we are now above threshold
            if confidence >= CONFIDENCE_THRESHOLD:
                new_importance_done.add(trait_id)

        if len(new_importance_done) >= total_traits:
            reply_text = (
                reply_text
                + "\n\n"
                + "That’s enough for me to lock in what actually matters to you in a match."
            )
            logger.info("[PREF %s] all traits now done after this turn", request_id)

    reply_text = _add_random_emoji(reply_text)

    # Debug info for UI/logging
    debug_active_traits: List[Dict[str, Any]] = []
    for tid in sorted(active_ids):
        state = existing_state.get(tid, {})
        name = next(
            (t["name"] for t in all_traits if int(t["id"]) == tid),
            f"Trait {tid}",
        )
        debug_active_traits.append(
            {
                "id": tid,
                "name": name,
                "score": state.get("score"),
                "confidence": state.get("confidence"),
            }
        )

    debug_payload = {
        "active_trait_ids": sorted(active_ids),
        "active_traits": debug_active_traits,
        "updated_traits": updated_debug,
    }

    logger.info(
        "[PREF %s] end updated_traits=%s importance_done=%s debug=%s",
        request_id,
        updated,
        sorted(new_importance_done),
        debug_payload,
    )

    return {
        "reply": reply_text,
        "phase": "importance",
        "updated_traits": updated,
        "progress": {
            "importance_filled": len(new_importance_done),
            "importance_total": total_traits,
        },
        "importance_done": sorted(new_importance_done),
        "debug": debug_payload,
    }
