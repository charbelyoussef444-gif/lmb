import os
import random
import re
import uuid
import json
import asyncio
import logging
from typing import Dict, List, Optional, Set, Any

from sqlalchemy import text
from openai import OpenAI

from app.db.engine import engine

logger = logging.getLogger(__name__)

OPENAI_MODEL = "gpt-4o"

EMOJIS = ["🙂", "😊", "😄", "🌟", "💫", "💛", "💙", "🌈", "✨", "🧠"]

# Sequential: we effectively focus on ONE trait at a time now.
TRAITS_PER_BATCH = 1

# Confidence at which we treat a trait as "good enough" for routing
CONFIDENCE_THRESHOLD = 0.7

# Canonical trait anchors for Phase-1 traits.
TRAIT_DEFINITIONS: Dict[int, str] = {
    1: (
        "Warmth / Compassion: genuine concern for others’ well-being and a "
        "nurturing, caring style in close relationships. High = naturally "
        "supportive and emotionally present; low = more detached or pragmatic."
    ),
    2: (
        "Honesty–Humility: inclination toward fairness, sincerity, and modesty "
        "rather than entitlement or exploitation. High = fair, humble, "
        "transparent; low = more willing to bend rules or self-promote."
    ),
    3: (
        "Attachment Anxiety: fear of rejection or abandonment and "
        "hypervigilance about a partner’s signals. High = worries when not "
        "reassured or contacted; low = generally secure and not preoccupied."
    ),
    4: (
        "Attachment Avoidance: discomfort with dependence or emotional "
        "intimacy and a strong preference for self-reliance. High = keeps "
        "distance, struggles with vulnerability; low = comfortable with closeness."
    ),
    5: (
        "Openness — Aesthetic / Experiential: receptivity to sensory, artistic, "
        "and novel experiences. High = drawn to art, culture, unusual ideas or "
        "places; low = prefers familiar, mainstream experiences."
    ),
    6: (
        "Repair Orientation: readiness to take ownership, apologize, and "
        "initiate repair after conflict. High = actively tries to fix things; "
        "low = avoids apologies or lets conflicts linger."
    ),
    7: (
        "Autonomy / Boundary Respect: respect for a partner’s independence and "
        "avoidance of controlling behavior. High = honors boundaries and space; "
        "low = intrusive, controlling, or dismissive of ‘no’."
    ),
    8: (
        "Communication Clarity / Directness: ability to express needs, "
        "feelings, and boundaries openly and concretely. High = says what they "
        "mean; low = hints, withdraws, or stays vague."
    ),
    9: (
        "Reliability / Dependability in Dyad: consistency in keeping promises, "
        "showing up, and being someone a partner can count on. High = follows "
        "through; low = flaky and inconsistent."
    ),
    10: (
        "Exclusivity Preference: personal comfort and desire for strict "
        "monogamy versus openness to consensual non-monogamy or more flexible "
        "relationship structures. High = strongly prefers strict exclusivity; "
        "low = more open to non-exclusive setups."
    ),
}


def get_openai_client() -> OpenAI:
    return OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


# ---------- small helpers ----------


def _extract_number(user_text: str) -> Optional[float]:
    """
    Pull the first float-like number out of user_text.
    Kept for potential future use.
    """
    matches = re.findall(r"[-+]?\d*\.?\d+", user_text)
    if not matches:
        return None
    try:
        value = float(matches[0])
    except ValueError:
        return None

    if 0.0 <= value <= 1.0:
        return value
    if 1.0 < value <= 100.0:
        return value / 100.0
    return None


async def _upsert_user_personality(
    conn,
    user_id: uuid.UUID,
    trait_id: int,
    score: float,
    confidence: float,
):
    """
    Upsert the user's trait score + confidence.

    Table: user_personality(user_id, trait_id, score, confidence).
    """
    await conn.execute(
        text(
            """
            INSERT INTO user_personality (user_id, trait_id, score, confidence)
            VALUES (:uid, :tid, :score, :conf)
            ON CONFLICT (user_id, trait_id)
            DO UPDATE SET
                score = EXCLUDED.score,
                confidence = EXCLUDED.confidence
            """
        ),
        {
            "uid": str(user_id),
            "tid": trait_id,
            "score": score,
            "conf": confidence,
        },
    )
    logger.debug(
        "Upserted SELF score user=%s trait=%s score=%.4f confidence=%.4f",
        user_id,
        trait_id,
        score,
        confidence,
    )


def _add_random_emoji(text: str) -> str:
    t = text.rstrip()
    lower = t.lower()

    if any(k in lower for k in ["technical hiccup", "got a bit lost"]):
        return t

    if "OPTIONS:" in t:
        return t

    if random.random() < 0.6:
        emoji = random.choice(EMOJIS)
        return f"{t} {emoji}"
    return t


def _build_history_snippet(history: List[str], max_items: int = 6) -> str:
    if not history:
        return ""
    labeled: List[str] = []
    start = max(0, len(history) - max_items)
    for idx, h in enumerate(history[start:], start=start + 1):
        labeled.append(f"Turn {idx}: {h}")
    snippet = "\n\n".join(labeled)
    logger.debug("History snippet for SELF model:\n%s", snippet)
    return snippet


def _prepare_traits_for_prompt(
    traits: List[dict],
    existing_state: Optional[Dict[int, Dict[str, Optional[float]]]] = None,
) -> List[dict]:
    """
    Normalize traits into a compact JSON payload for the model.
    """
    prepared: List[dict] = []
    existing_state = existing_state or {}

    for t in traits:
        try:
            tid = int(t["id"])
        except (KeyError, TypeError, ValueError):
            continue

        name = t.get("name", f"Trait {tid}")
        description = TRAIT_DEFINITIONS.get(tid)
        if not description:
            description = (
                f"{name}: how this dimension typically shows up in romantic "
                "relationships, behavior, and preferences."
            )

        trait_payload: Dict[str, Any] = {
            "id": tid,
            "name": name,
            "description": description,
        }

        state = existing_state.get(tid)
        if state is not None:
            if state.get("score") is not None:
                trait_payload["current_value"] = float(state["score"])
            if state.get("confidence") is not None:
                trait_payload["current_confidence"] = float(state["confidence"])

        prepared.append(trait_payload)

    logger.debug("Prepared SELF traits for model: %s", prepared)
    return prepared


# ---------- OpenAI call: SELF phase ----------


async def _call_openai_for_multi_trait_analysis(
    traits: List[dict],
    history: List[str],
    user_text: str,
    existing_state: Optional[Dict[int, Dict[str, Optional[float]]]] = None,
) -> Dict:
    """
    Self phase:
      - Infer 0–1 self trait scores + confidence for the given (usually single) trait.
      - Ask ONE short open question to refine that trait (no MCQs).
    """
    client = get_openai_client()

    prepared_traits = _prepare_traits_for_prompt(traits, existing_state=existing_state)

    payload = {
        "traits": prepared_traits,
        "recent_history": _build_history_snippet(history),
        "latest_user_message": user_text,
    }

    logger.debug(
        "Calling OpenAI SELF-phase with payload: %s",
        json.dumps(payload, ensure_ascii=False),
    )

    system_prompt = """
You are a fast, playful, but very sharp personality-assessment chatbot for a dating app.

OVERALL GOAL
- Build an accurate, quantitative profile of the user on the romantic-relationship traits provided to you.
- You typically see EXACTLY ONE ACTIVE trait at a time in the "traits" list.
- Focus on that trait until your confidence is high before moving on.

RELATIONSHIP STATUS CONSTRAINTS
- Never assume the user currently has a partner; many users are single.
- When talking about romantic behavior, use hypothetical or general close-relationship framing:
  - “in close relationships (friends, family, or when you’re with a partner)”
  - “if/when you’re with a partner, how would you usually…”
- Do NOT phrase questions as if they definitely have a current partner.

ON EACH TURN YOU MUST
1) Read all context (recent_history + latest_user_message + existing trait estimates).
2) For the ACTIVE trait where you have ANY directional signal, output:
   - a numeric value in [0.0, 1.0]
   - a confidence in [0.0, 1.0]
   - a short explanation tied to concrete behavior or self-description.
3) Treat confidence around 0.7 or higher as "pretty solid". For traits below that, plan to keep
   gathering information on future turns.
4) Ask EXACTLY ONE short open question that targets this active trait.
5) Keep the conversation light, flirty, and fun, but never waste words.

SCALE (for values you output)
- 0.0 = extremely low on that trait
- 0.5 = average / mixed / context-dependent
- 1.0 = extremely high on that trait
- You MUST output numeric values between 0 and 1 inclusive.

CONFIDENCE INTERPRETATION
- confidence ~0.3: weak hunch, little evidence
- confidence ~0.5: moderate, could easily update with new info
- confidence ~0.7+: strong, unlikely to change drastically
- Do NOT artificially inflate confidence.

QUESTION STRATEGY
- Only ask simple open questions (no multiple choice, no lists of options).
- Avoid any “A/B/C/D” options or numbered answer choices.
- You MUST NOT assume a specific situation has actually happened to the user.
  - If you reference a “time” or “situation”, always allow hypotheticals:
    - “Think about a time (or imagine a situation if it hasn’t really happened) where…”
    - “If nothing specific comes to mind, tell me how you *think* you’d react or what would feel right or wrong.”
- It is fine to ask about “someone”, but NEVER require that they name a specific person:
  - “Think about a person or situation where… if nothing clear pops up, describe the kind of scenario that fits.”
- Keep questions concrete and behavior-focused:
  - reactions,
  - typical patterns,
  - what they actually do or feel inside.

STYLE / UX
- Tone: playful, curious, slightly flirty, but respectful.
- Reply length: at most 2–3 short sentences OR ~60 words.
- Never dump a long list of numbers to the user.
- ALWAYS end your reply with exactly one short open question (or no question if we are clearly wrapping up a trait).

OUTPUT FORMAT (STRICT)
Respond as a single valid JSON object, with no extra text, no markdown:

{
  "reply": "<what you say to the user in natural language>",
  "inferred": [
    {
      "trait_id": <int from the 'traits' payload>,
      "trait_name": "<string>",
      "value": <float between 0 and 1>,
      "confidence": <float between 0 and 1>,
      "explanation": "<short, plain-language reason tied to behavior or statements>"
    },
    ...
  ]
}
"""
    try:
        loop = asyncio.get_event_loop()
        completion = await loop.run_in_executor(
            None,
            lambda: client.chat.completions.create(
                model=OPENAI_MODEL,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": json.dumps(payload),
                    },
                ],
                temperature=0.3,
            ),
        )
    except Exception as e:
        logger.exception("OpenAI API call failed in SELF phase: %s", e)
        return {
            "reply": (
                "I'm having a small technical hiccup. "
                "Tell me a bit more about how you usually act with friends or in close relationships."
            ),
            "inferred": [],
        }

    raw = (completion.choices[0].message.content or "").strip()
    logger.debug("SELF raw OpenAI response: %s", raw)

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        logger.warning("JSON decode error in SELF phase: %s | raw=%r", e, raw)
        return {
            "reply": (
                "I got a bit lost in that last part. "
                "Tell me a bit more about how you usually act with friends or people you’re close to."
            ),
            "inferred": [],
        }

    if not isinstance(data, dict):
        logger.warning("SELF response was not a dict, got: %r", type(data))
        data = {}

    if "reply" not in data or not isinstance(data["reply"], str):
        data["reply"] = (
            "Got it. Tell me a bit more about how you see yourself in everyday situations."
        )

    if "inferred" not in data or not isinstance(data["inferred"], list):
        data["inferred"] = []

    logger.debug("Parsed SELF data: %s", data)
    return data


# ---------- main self-phase handler ----------


async def handle_self_phase(
    user_id: uuid.UUID,
    conversation_id: uuid.UUID,
    all_traits: List[dict],
    total_traits: int,
    user_self_done: Set[int],
    user_text: str,
    history: List[str],
) -> Dict:
    """
    Phase 1: self scores in user_personality, strictly sequential.

    - We only move to the next trait when the current trait's DB confidence
      reaches CONFIDENCE_THRESHOLD (>= 0.7).
    - At any moment, exactly one active trait is being hammered.
    """
    request_id = uuid.uuid4()
    logger.info(
        "[SELF] start request_id=%s user=%s conv=%s text=%r",
        request_id,
        user_id,
        conversation_id,
        user_text,
    )

    # Fetch existing personality state (score + confidence)
    async with engine.begin() as conn:
        result = await conn.execute(
            text(
                """
                SELECT trait_id, score, confidence
                FROM user_personality
                WHERE user_id = :uid
                """
            ),
            {"uid": str(user_id)},
        )
        rows = result.fetchall()

    existing_state: Dict[int, Dict[str, Optional[float]]] = {}
    for row in rows:
        m = row._mapping
        try:
            tid = int(m["trait_id"])
        except (KeyError, TypeError, ValueError):
            continue
        existing_state[tid] = {
            "score": m.get("score"),
            "confidence": m.get("confidence"),
        }

    logger.debug("[SELF %s] existing_state=%s", request_id, existing_state)

    # Traits that are not yet "done" according to router (confidence >= threshold)
    new_self_done: Set[int] = set(user_self_done)

    remaining_traits = [t for t in all_traits if int(t["id"]) not in new_self_done]
    logger.debug(
        "[SELF %s] remaining_traits_ids=%s",
        request_id,
        [t["id"] for t in remaining_traits],
    )

    if not remaining_traits:
        msg = (
            "I've already captured your personality profile. "
            "Next we'll talk about what you want in a match."
        )
        msg = _add_random_emoji(msg)
        logger.info("[SELF %s] all traits done, replying with summary", request_id)
        return {
            "reply": msg,
            "phase": "self",
            "progress": {
                "self_filled": len(new_self_done),
                "self_total": total_traits,
            },
            "self_done": sorted(new_self_done),
        }

    # STRICTLY SEQUENTIAL:
    # Always focus on the first trait that is not yet done.
    active_trait = remaining_traits[0]
    active_traits = [active_trait]
    active_ids = {int(active_trait["id"])}
    logger.debug("[SELF %s] active_traits_ids=%s", request_id, sorted(active_ids))

    # Build prior state for that active trait only
    active_existing_state: Dict[int, Dict[str, Optional[float]]] = {
        tid: existing_state.get(tid, {"score": None, "confidence": None})
        for tid in active_ids
    }

    analysis = await _call_openai_for_multi_trait_analysis(
        traits=active_traits,
        history=history,
        user_text=user_text,
        existing_state=active_existing_state,
    )

    reply_text = (analysis.get("reply") or "").strip()
    if not reply_text:
        reply_text = (
            "Got it. Tell me a bit more about how you see yourself in everyday situations."
        )

    inferred = analysis.get("inferred") or []
    logger.debug("[SELF %s] inferred=%s", request_id, inferred)

    updated: Dict[str, float] = {}
    updated_debug: Dict[str, Dict[str, Optional[float]]] = {}

    async with engine.begin() as conn:
        # Store ALL inferences that pass sanity checks.
        for item in inferred:
            try:
                trait_id = int(item.get("trait_id"))
                value = float(item.get("value"))
                confidence = float(item.get("confidence", 0.0))
            except (TypeError, ValueError):
                logger.warning("[SELF %s] Invalid inferred item: %r", request_id, item)
                continue

            if trait_id not in active_ids:
                logger.debug(
                    "[SELF %s] skipping inferred trait_id=%s not in active_ids=%s",
                    request_id,
                    trait_id,
                    active_ids,
                )
                continue

            # Clamp to [0, 1]
            value = max(0.0, min(1.0, value))
            confidence = max(0.0, min(1.0, confidence))

            # Enforce monotonic confidence: never let it go down
            prev_state = existing_state.get(trait_id, {})
            prev_conf_raw = prev_state.get("confidence")
            try:
                prev_conf = float(prev_conf_raw) if prev_conf_raw is not None else None
            except (TypeError, ValueError):
                prev_conf = None

            if prev_conf is not None and prev_conf > confidence:
                logger.debug(
                    "[SELF %s] keeping higher previous confidence for trait=%s: prev=%.4f new=%.4f",
                    request_id,
                    trait_id,
                    prev_conf,
                    confidence,
                )
                confidence = prev_conf

            await _upsert_user_personality(conn, user_id, trait_id, value, confidence)
            updated[str(trait_id)] = value

            existing_state[trait_id] = {"score": value, "confidence": confidence}
            updated_debug[str(trait_id)] = {
                "score": value,
                "confidence": confidence,
            }

            # Mark done locally if we are now above threshold
            if confidence >= CONFIDENCE_THRESHOLD:
                new_self_done.add(trait_id)

        if len(new_self_done) >= total_traits:
            reply_text = (
                reply_text
                + "\n\n"
                + "That's enough for me to build your personal profile. "
                "Next we'll talk about what you want in a match."
            )
            logger.info("[SELF %s] all traits now done after this turn", request_id)

    reply_text = _add_random_emoji(reply_text)

    # Debug info for UI/logging
    debug_active_traits: List[Dict[str, Any]] = []
    for tid in sorted(active_ids):
        state = existing_state.get(tid, {})
        name = next(
            (t["name"] for t in all_traits if int(t["id"]) == tid),
            f"Trait {tid}",
        )
        debug_active_traits.append(
            {
                "id": tid,
                "name": name,
                "score": state.get("score"),
                "confidence": state.get("confidence"),
            }
        )

    debug_payload = {
        "active_trait_ids": sorted(active_ids),
        "active_traits": debug_active_traits,
        "updated_traits": updated_debug,
    }

    logger.info(
        "[SELF %s] end updated_traits=%s self_done=%s debug=%s",
        request_id,
        updated,
        sorted(new_self_done),
        debug_payload,
    )

    return {
        "reply": reply_text,
        "phase": "self",
        "updated_traits": updated,
        "progress": {
            "self_filled": len(new_self_done),
            "self_total": total_traits,
        },
        "self_done": sorted(new_self_done),
        "debug": debug_payload,
    }
