import uuid
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends
from app.deps.auth import get_current_user_id
from app.services.storage import upload_file, make_photo_key
from app.services.supabase import sb
from app.core.config import settings
from pydantic import BaseModel

router = APIRouter(prefix="/me/photos", tags=["photos"])

class UploadResult(BaseModel):
    ok: bool
    photo_id: str
    path: str

@router.post("/gallery", response_model=UploadResult)
async def upload_gallery_photo(
    file: UploadFile = File(...),
    position: int = Form(1),
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    if position not in (1, 2, 3):
        raise HTTPException(400, "position must be 1, 2, or 3")
    key = make_photo_key(str(user_id), "gallery", position)
    path = await upload_file(file, key)
    return {"ok": True, "photo_id": key.rsplit("/", 1)[-1], "path": path}

@router.post("/verification", response_model=UploadResult)
async def upload_verification_id(
    file: UploadFile = File(...),
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    key = make_photo_key(str(user_id), "verification_id")
    path = await upload_file(file, key)
    return {"ok": True, "photo_id": key.rsplit("/", 1)[-1], "path": path}

# app/api/routes/photos.py
@router.get("")
async def list_my_photos(user_id: uuid.UUID = Depends(get_current_user_id)):
    prefix = str(user_id)
    bucket = sb.storage.from_(settings.STORAGE_BUCKET)

    urls: list[str] = []

    # list gallery images
    items = bucket.list(path=f"{prefix}/gallery")
    for it in items or []:
        # folders typically have no metadata; files do
        if not it.get("name") or not it.get("metadata"):
            continue
        key = f"{prefix}/gallery/{it['name']}"
        signed = bucket.create_signed_url(path=key, expires_in=600)
        urls.append(signed["signedURL"])

    # (optional) include verification images if you want them shown too
    # vitems = bucket.list(path=f"{prefix}/kyc")
    # for it in vitems or []:
    #     if not it.get("name") or not it.get("metadata"):
    #         continue
    #     key = f"{prefix}/kyc/{it['name']}"
    #     signed = bucket.create_signed_url(path=key, expires_in=600)
    #     urls.append(signed["signedURL"])

    return urls

