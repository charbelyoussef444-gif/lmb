# app/api/routes/profile.py
import uuid
from typing import List, Optional

from fastapi import APIRouter, Body, HTTPException, Depends
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.db.engine import engine
from app.deps.auth import get_current_user_id

router = APIRouter(prefix="/me", tags=["me"])


class ProfileOut(BaseModel):
    id: str
    full_name: str
    gender: Optional[str] = None
    age: Optional[int] = None
    location: Optional[str] = None
    personality_weight: float
    interests_weight: float
    verified: bool
    admin: bool = False

    # NEW: match preferences (mapped from preferred_min_age, preferred_max_age, gender_pref in DB)
    preferred_min_age: Optional[int] = None
    preferred_max_age: Optional[int] = None
    preferred_gender: Optional[str] = None  # "women" | "men" | "everyone" (from gender_pref)


class OnboardingIn(BaseModel):
    age: int = Field(..., ge=18, le=99)
    location: Optional[str] = None
    # NEW: self gender ("woman" | "man" | "nonbinary" or similar)
    gender: Optional[str] = None
    preferred_min_age: Optional[int] = None
    preferred_max_age: Optional[int] = None
    preferred_gender: Optional[str] = None  # "women" | "men" | "everyone"


class WeightsIn(BaseModel):
    personality_weight: float = Field(ge=0.0, le=1.0)
    interests_weight: float = Field(ge=0.0, le=1.0)


class InterestIn(BaseModel):
    name: str


class InterestOut(BaseModel):
    id: int
    name: str
    category: Optional[str] = None


# NEW: input model for match preferences update
class MatchPreferencesIn(BaseModel):
    # DB already has constraints preferred_min_age > 17 and preferred_max_age > preferred_min_age
    preferred_min_age: Optional[int] = None
    preferred_max_age: Optional[int] = None
    # stored in DB as gender_pref
    preferred_gender: Optional[str] = None  # expect "women" | "men" | "everyone"


@router.get("", response_model=ProfileOut)
async def get_me(user_id: uuid.UUID = Depends(get_current_user_id)):
    """
    Fetch the current user's profile. If missing, create a default row.
    """
    async with engine.begin() as conn:
        row = (
            await conn.execute(
                text(
                    """
            select id::text,
                   full_name,
                   gender,
                   age,
                   location,
                   personality_weight,
                   interests_weight,
                   verified,
                   admin,
                   preferred_min_age,
                   preferred_max_age,
                   gender_pref as preferred_gender
            from users
            where id = :uid
            """
                ),
                {"uid": str(user_id)},
            )
        ).mappings().first()

        if not row:
            # create default profile (weights kept for future use)
            row = (
                await conn.execute(
                    text(
                        """
                insert into users (
                    id,
                    full_name,
                    verified,
                    personality_weight,
                    interests_weight,
                    created_at,
                    updated_at
                )
                values (:uid, 'New User', false, 0.5, 0.5, now(), now())
                returning id::text,
                          full_name,
                          gender,
                          age,
                          location,
                          personality_weight,
                          interests_weight,
                          verified,
                          admin,
                          preferred_min_age,
                          preferred_max_age,
                          gender_pref as preferred_gender
                """
                    ),
                    {"uid": str(user_id)},
                )
            ).mappings().first()

    return row


@router.get("/interests", response_model=List[InterestOut])
async def my_interests(user_id: uuid.UUID = Depends(get_current_user_id)):
    async with engine.begin() as conn:
        rows = (
            await conn.execute(
                text(
                    """
            select i.id, i.name, i.category
            from user_interests ui
            join interests i on i.id = ui.interest_id
            where ui.user_id = :uid
            order by i.name
            """
                ),
                {"uid": str(user_id)},
            )
        ).mappings().all()
    return rows


# NEW: all interests in the system (for the picker in ProfilePage)
@router.get("/interests/all", response_model=List[InterestOut])
async def all_interests():
    async with engine.begin() as conn:
        rows = (
            await conn.execute(
                text(
                    """
            select id, name, category
            from interests
            order by name
            """
                )
            )
        ).mappings().all()
    return rows


@router.put("/interests", response_model=List[InterestOut])
async def put_my_interests(
    items: List[InterestIn] = Body(...),
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    """
    Replace the current user's interests with the provided list of names.
    Uses interests table (id, name, category) and user_interests (user_id, interest_id).
    """
    names = [i.name.strip() for i in items if i.name.strip()]
    async with engine.begin() as conn:
        ids: List[int] = []
        for name in names:
            r = (
                await conn.execute(
                    text(
                        """
                insert into interests(name)
                values (:name)
                on conflict (name) do update set name = excluded.name
                returning id
                """
                    ),
                    {"name": name},
                )
            ).first()
            ids.append(r[0])

        # Clear existing user interests and insert new ones
        await conn.execute(
            text("delete from user_interests where user_id = :uid"),
            {"uid": str(user_id)},
        )
        for iid in ids:
            await conn.execute(
                text(
                    "insert into user_interests(user_id, interest_id) values (:u,:i)"
                ),
                {"u": str(user_id), "i": iid},
            )

        rows = (
            await conn.execute(
                text(
                    """
            select i.id, i.name, i.category
            from user_interests ui
            join interests i on i.id = ui.interest_id
            where ui.user_id = :uid
            order by i.name
            """
                ),
                {"uid": str(user_id)},
            )
        ).mappings().all()
    return rows


@router.put("/weights", response_model=ProfileOut)
async def update_weights(
    body: WeightsIn, user_id: uuid.UUID = Depends(get_current_user_id)
):
    """
    Update personality/interests weights.
    Frontend currently doesn't expose controls for this, but we keep it for future use.
    """
    if abs((body.personality_weight + body.interests_weight) - 1.0) > 0.01:
        raise HTTPException(400, "weights must sum to ≈ 1.0")
    async with engine.begin() as conn:
        row = (
            await conn.execute(
                text(
                    """
            update users
            set personality_weight = :pw,
                interests_weight   = :iw,
                updated_at         = now()
            where id = :uid
            returning id::text,
                      full_name,
                      gender,
                      age,
                      location,
                      personality_weight,
                      interests_weight,
                      verified,
                      admin,
                      preferred_min_age,
                      preferred_max_age,
                      gender_pref as preferred_gender
            """
                ),
                {
                    "pw": body.personality_weight,
                    "iw": body.interests_weight,
                    "uid": str(user_id),
                },
            )
        ).mappings().first()
        if not row:
            raise HTTPException(404, "User not found")
    return row


@router.put("/preferences", response_model=ProfileOut)
async def update_match_preferences(
    body: MatchPreferencesIn,
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    """
    Update match preferences: preferred_min_age, preferred_max_age, gender preference.

    DB columns:
      - preferred_min_age
      - preferred_max_age
      - gender_pref (exposed as preferred_gender)
    """

    # Basic sanity checks (DB has stronger constraints already)
    if (
        body.preferred_min_age is not None
        and body.preferred_max_age is not None
        and body.preferred_min_age > body.preferred_max_age
    ):
        raise HTTPException(
            400, "preferred_min_age cannot be greater than preferred_max_age"
        )

    if body.preferred_gender is not None and body.preferred_gender not in (
        "women",
        "men",
        "everyone",
    ):
        raise HTTPException(
            400, "preferred_gender must be one of: women, men, everyone"
        )

    async with engine.begin() as conn:
        row = (
            await conn.execute(
                text(
                    """
            update users
            set preferred_min_age = :pmin,
                preferred_max_age = :pmax,
                gender_pref       = :pgender,
                updated_at        = now()
            where id = :uid
            returning id::text,
                      full_name,
                      gender,
                      age,
                      location,
                      personality_weight,
                      interests_weight,
                      verified,
                      admin,
                      preferred_min_age,
                      preferred_max_age,
                      gender_pref as preferred_gender
            """
                ),
                {
                    "pmin": body.preferred_min_age,
                    "pmax": body.preferred_max_age,
                    "pgender": body.preferred_gender,
                    "uid": str(user_id),
                },
            )
        ).mappings().first()

        if not row:
            raise HTTPException(404, "User not found")

    return row


@router.put("/onboarding", response_model=ProfileOut)
async def complete_onboarding(
    body: OnboardingIn,
    user_id: uuid.UUID = Depends(get_current_user_id),
):
    # extra safety on age pref
    if (
        body.preferred_min_age is not None
        and body.preferred_max_age is not None
        and body.preferred_min_age > body.preferred_max_age
    ):
        raise HTTPException(
            400, "preferred_min_age cannot be greater than preferred_max_age"
        )

    if body.preferred_gender is not None and body.preferred_gender not in (
        "women",
        "men",
        "everyone",
    ):
        raise HTTPException(
            400, "preferred_gender must be one of: women, men, everyone"
        )

    async with engine.begin() as conn:
        row = (
            await conn.execute(
                text(
                    """
            update users
            set age               = :age,
                gender            = :gender,
                location          = :loc,
                preferred_min_age = :pmin,
                preferred_max_age = :pmax,
                gender_pref       = :pgender,
                updated_at        = now()
            where id = :uid
            returning id::text,
                      full_name,
                      gender,
                      age,
                      location,
                      personality_weight,
                      interests_weight,
                      verified,
                      admin,
                      preferred_min_age,
                      preferred_max_age,
                      gender_pref as preferred_gender
            """
                ),
                {
                    "age": body.age,
                    "gender": body.gender,
                    "loc": body.location,
                    "pmin": body.preferred_min_age,
                    "pmax": body.preferred_max_age,
                    "pgender": body.preferred_gender,
                    "uid": str(user_id),
                },
            )
        ).mappings().first()

        if not row:
            raise HTTPException(404, "User not found")

    return row
