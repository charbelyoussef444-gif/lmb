# app/main.py
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.api.routes import debug, profile, conversations, photos  # ← single import line incl. photos
from app.core.config import settings
from app.db.engine import engine
from app.api.routes.ws import ws_router  # ← add
from app.api.routes import matching
from app.api.routes.me_kyc import router as me_kyc_router
from app.api.routes.admin_kyc import router as admin_kyc_router
from app.api.routes.admin_users import router as admin_users_router
from app.api.routes.chatbot import router as chatbot_router
from app.api.routes.traits import router as traits_router

logger = logging.getLogger("uvicorn.error")

app = FastAPI(title="LikeMinded API (MVP)")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # ← TEMP: allow all origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(debug.router)
app.include_router(profile.router)
app.include_router(conversations.router)
app.include_router(photos.router)  # ← ADD THIS LINE
app.include_router(ws_router)  # ← add
app.include_router(matching.router)
app.include_router(me_kyc_router)
app.include_router(admin_kyc_router)
app.include_router(admin_users_router)
app.include_router(chatbot_router)
app.include_router(traits_router)


@app.on_event("startup")
async def _startup_probe():
    try:
        logger.info("[startup] DB driver: %s", engine.url.drivername)
        async with engine.begin() as conn:
            v = (await conn.execute(text("select 1"))).scalar_one()
            logger.info("[startup] DB ping OK: %s", v)
        # optional: show what routes actually loaded
        for r in app.routes:
            logger.info(
                "Route loaded: %s %s",
                getattr(r, "methods", None),
                getattr(r, "path", None),
            )
    except Exception:
        logger.exception("[startup] DB ping FAILED")
